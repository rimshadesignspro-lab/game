
import React, { useState, useCallback } from 'react';
import { Header } from './components/Header';
import { LeftSidebar } from './components/LeftSidebar';
import { Editor } from './components/Editor';
import { RightSidebar } from './components/RightSidebar';
import { Asset } from './types';
import { INITIAL_ASSETS, INITIAL_BACKGROUND } from './constants';
import { generateImageEdit } from './services/geminiService';

const App: React.FC = () => {
  const [assets, setAssets] = useState<Asset[]>(INITIAL_ASSETS);
  const [selectedAsset, setSelectedAsset] = useState<Asset | null>(assets[0] || null);
  const [currentBackground, setCurrentBackground] = useState<string>(INITIAL_BACKGROUND);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleSelectAsset = useCallback((asset: Asset) => {
    setSelectedAsset(asset);
  }, []);

  const handleFileUpload = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const newAsset: Asset = {
        id: `asset-${Date.now()}`,
        name: file.name,
        url: e.target?.result as string,
        type: 'image',
        mimeType: file.type,
      };
      setAssets(prev => [newAsset, ...prev]);
      setSelectedAsset(newAsset);
    };
    reader.readAsDataURL(file);
  };
  
  const handleGenerate = async (prompt: string) => {
    if (!selectedAsset || !selectedAsset.url.startsWith('data:')) {
      setError("Please select an uploaded image to edit. Editing sample assets is not supported.");
      return;
    }

    setIsLoading(true);
    setError(null);
    try {
      const base64Data = selectedAsset.url.split(',')[1];
      if (!base64Data || !selectedAsset.mimeType) {
        throw new Error("Invalid image data or MIME type.");
      }
      
      const newImageUrl = await generateImageEdit(base64Data, selectedAsset.mimeType, prompt);

      // Create a new asset with the edited image
      const newAsset: Asset = {
        ...selectedAsset,
        id: `asset-${Date.now()}`,
        url: newImageUrl,
        name: `${selectedAsset.name} (edited)`,
      };

      // Replace the old asset with the new one
      setAssets(prev => [newAsset, ...prev.filter(a => a.id !== selectedAsset.id)]);
      setSelectedAsset(newAsset);

    } catch (err) {
      console.error(err);
      setError(err instanceof Error ? err.message : "An unknown error occurred.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="bg-[#1F2937] text-white min-h-screen font-sans flex flex-col">
      <Header />
      <main className="flex-grow flex overflow-hidden">
        <LeftSidebar 
          assets={assets} 
          selectedAsset={selectedAsset}
          onSelectAsset={handleSelectAsset}
          onFileUpload={handleFileUpload}
        />
        <Editor 
          selectedAsset={selectedAsset} 
          backgroundUrl={currentBackground}
          isLoading={isLoading}
        />
        <RightSidebar 
          onGenerate={handleGenerate} 
          onSelectBackground={setCurrentBackground}
          isLoading={isLoading}
          error={error}
        />
      </main>
    </div>
  );
};

export default App;
