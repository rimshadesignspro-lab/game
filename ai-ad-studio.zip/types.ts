
export interface Asset {
  id: string;
  name: string;
  url: string; // This can be a URL or a data URL for uploaded files
  type: 'image'; // Can be expanded later
  mimeType?: string; // e.g., 'image/png'
}
