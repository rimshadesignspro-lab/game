
import React, { useRef } from 'react';
import { Asset } from '../types';

interface LeftSidebarProps {
  assets: Asset[];
  selectedAsset: Asset | null;
  onSelectAsset: (asset: Asset) => void;
  onFileUpload: (file: File) => void;
}

export const LeftSidebar: React.FC<LeftSidebarProps> = ({ assets, selectedAsset, onSelectAsset, onFileUpload }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleUploadClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      onFileUpload(file);
    }
  };
  
  return (
    <aside className="w-1/5 bg-[#111827] p-6 flex flex-col space-y-8 overflow-y-auto">
      <div>
        <h2 className="text-sm font-semibold text-gray-400 uppercase tracking-wider mb-4">ASSET LIBRARY</h2>
        <div className="grid grid-cols-2 gap-4">
          {assets.map(asset => (
            <div 
              key={asset.id} 
              className={`relative rounded-lg overflow-hidden cursor-pointer aspect-square border-2 transition-all
                ${selectedAsset?.id === asset.id ? 'border-cyan-400 shadow-lg shadow-cyan-500/20' : 'border-gray-700 hover:border-cyan-500'}`}
              onClick={() => onSelectAsset(asset)}
            >
              <img src={asset.url} alt={asset.name} className="w-full h-full object-contain" />
              <div className="absolute inset-0 bg-black bg-opacity-20 hover:bg-opacity-0 transition-opacity"></div>
            </div>
          ))}
        </div>
      </div>
      <div>
        <h2 className="text-sm font-semibold text-gray-400 uppercase tracking-wider mb-4">UPLOAD YOUR IMAGES</h2>
        <input 
          type="file" 
          ref={fileInputRef} 
          onChange={handleFileChange} 
          className="hidden" 
          accept="image/png, image/jpeg, image/webp"
        />
        <button 
          onClick={handleUploadClick}
          className="w-full bg-cyan-500 text-gray-900 font-bold py-3 px-4 rounded-lg hover:bg-cyan-400 transition-all shadow-md hover:shadow-lg shadow-cyan-500/20"
        >
          DRAG & DROP OR BROWSE
        </button>
        <p className="text-xs text-gray-500 mt-2 text-center">For best results, upload PNGs with transparent backgrounds.</p>
      </div>
    </aside>
  );
};
