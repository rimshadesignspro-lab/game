
import React, { useState } from 'react';
import { StarIcon, SpinnerIcon } from './Icons';
import { BACKGROUND_SUGGESTIONS } from '../constants';

interface RightSidebarProps {
  onGenerate: (prompt: string) => void;
  onSelectBackground: (url: string) => void;
  isLoading: boolean;
  error: string | null;
}

export const RightSidebar: React.FC<RightSidebarProps> = ({ onGenerate, onSelectBackground, isLoading, error }) => {
  const [prompt, setPrompt] = useState<string>('');

  const handleGenerateClick = () => {
    if (prompt && !isLoading) {
      onGenerate(prompt);
    }
  };

  return (
    <aside className="w-1/5 bg-[#111827] p-6 flex flex-col space-y-8 overflow-y-auto">
      <div>
        <h2 className="text-sm font-semibold text-gray-400 uppercase tracking-wider mb-4">AI IMAGE EDITOR</h2>
        <div className="space-y-4">
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Describe your desired edit... e.g., 'Add a retro filter' or 'Place it in a futuristic city at night'"
            className="w-full h-24 bg-gray-800 border border-gray-700 rounded-lg p-2 text-sm text-gray-200 placeholder-gray-500 focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition"
            disabled={isLoading}
          />
          {error && <p className="text-xs text-red-400">{error}</p>}
          <button 
            onClick={handleGenerateClick}
            disabled={isLoading || !prompt}
            className="w-full flex items-center justify-center bg-cyan-500 text-gray-900 font-bold py-3 px-4 rounded-lg hover:bg-cyan-400 transition-all shadow-md hover:shadow-lg shadow-cyan-500/20 disabled:bg-gray-600 disabled:cursor-not-allowed disabled:shadow-none"
          >
            {isLoading ? <SpinnerIcon className="w-5 h-5 animate-spin" /> : 'GENERATE'}
          </button>
        </div>
      </div>
      <div>
        <div className="grid grid-cols-2 gap-4">
          {BACKGROUND_SUGGESTIONS.map((bg, index) => (
            <img 
              key={index}
              src={bg} 
              alt={`Background suggestion ${index + 1}`}
              className="rounded-lg cursor-pointer aspect-square object-cover border-2 border-transparent hover:border-cyan-400 transition-all"
              onClick={() => onSelectBackground(bg)}
            />
          ))}
        </div>
        <button className="w-full mt-4 bg-gray-700 text-gray-300 font-bold py-3 px-4 rounded-lg hover:bg-gray-600 transition-colors">
          REPLACE BACKGROUND
        </button>
      </div>
      <div className="space-y-6">
        <div>
          <label className="flex items-center justify-between text-sm font-medium text-gray-400 mb-2">
            <span>LIGHTING</span>
            <StarIcon className="w-4 h-4 text-cyan-400" />
          </label>
          <input type="range" className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-cyan-400" />
        </div>
        <div>
          <label className="flex items-center justify-between text-sm font-medium text-gray-400 mb-2">
            <span>COLOR PALETTE</span>
            <StarIcon className="w-4 h-4 text-cyan-400" />
          </label>
          <input type="range" className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-cyan-400" />
        </div>
        <p className="text-xs text-gray-500 text-center">Sliders are for illustrative purposes. Use text prompts for precise control.</p>
      </div>
    </aside>
  );
};
