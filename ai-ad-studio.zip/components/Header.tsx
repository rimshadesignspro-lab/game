
import React from 'react';
import { UserCircleIcon, LogoutIcon } from './Icons';

export const Header: React.FC = () => {
  return (
    <header className="bg-[#111827] bg-opacity-80 backdrop-blur-sm border-b border-gray-700/50 shadow-lg sticky top-0 z-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex-shrink-0">
            <h1 className="text-2xl font-bold tracking-wider text-cyan-400">AD STUDIO AI</h1>
          </div>
          <nav className="hidden md:flex md:space-x-8">
            <a href="#" className="text-cyan-400 border-b-2 border-cyan-400 px-3 py-2 text-sm font-medium">HOME</a>
            <a href="#" className="text-gray-300 hover:text-white px-3 py-2 text-sm font-medium transition-colors">TEMPLATES</a>
            <a href="#" className="text-gray-300 hover:text-white px-3 py-2 text-sm font-medium transition-colors">MY PROJECTS</a>
            <a href="#" className="text-gray-300 hover:text-white px-3 py-2 text-sm font-medium transition-colors">PRICING</a>
          </nav>
          <div className="flex items-center space-x-4">
            <button className="p-2 rounded-full hover:bg-gray-700 transition-colors">
              <UserCircleIcon className="h-6 w-6 text-gray-300" />
            </button>
            <button className="flex items-center space-x-2 bg-gray-800 hover:bg-gray-700 px-3 py-2 rounded-md text-sm font-medium transition-colors">
              <LogoutIcon className="h-5 w-5 text-gray-400" />
              <span className="text-gray-300">LOGOUT</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
