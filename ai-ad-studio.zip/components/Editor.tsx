
import React from 'react';
import { Asset } from '../types';
import { EditIcon, ElementsIcon, TextIcon, ColorsIcon, LayersIcon, SpinnerIcon } from './Icons';

interface EditorProps {
  selectedAsset: Asset | null;
  backgroundUrl: string;
  isLoading: boolean;
}

export const Editor: React.FC<EditorProps> = ({ selectedAsset, backgroundUrl, isLoading }) => {
  return (
    <section className="flex-grow w-3/5 bg-gray-900/50 flex flex-col items-center justify-center p-8 relative">
      <div className="w-full max-w-4xl aspect-[16/9] bg-gray-800 rounded-lg shadow-2xl flex items-center justify-center relative overflow-hidden">
        {/* Background Image */}
        <img src={backgroundUrl} alt="Background" className="absolute inset-0 w-full h-full object-cover" />
        
        {/* Ad Content */}
        {selectedAsset && (
            <div className="relative w-full h-full flex items-center justify-center p-8">
                <img 
                    src={selectedAsset.url} 
                    alt={selectedAsset.name} 
                    className="max-h-[85%] max-w-[85%] object-contain drop-shadow-2xl transition-all duration-500"
                />
            </div>
        )}
        {!selectedAsset && (
            <div className="text-gray-500">Select an asset to begin</div>
        )}

        {/* Loading Overlay */}
        {isLoading && (
            <div className="absolute inset-0 bg-black/70 backdrop-blur-sm flex flex-col items-center justify-center z-10 transition-opacity">
                <SpinnerIcon className="w-12 h-12 animate-spin text-cyan-400" />
                <p className="mt-4 text-lg font-semibold">AI is working its magic...</p>
                <p className="text-sm text-gray-400">This can take a moment.</p>
            </div>
        )}

      </div>
      <div className="absolute bottom-4 flex space-x-4 bg-gray-800/50 backdrop-blur-sm p-2 rounded-lg">
        <button className="p-3 text-gray-400 hover:text-white hover:bg-gray-700 rounded-md transition-colors"><EditIcon className="w-5 h-5" /></button>
        <button className="p-3 text-gray-400 hover:text-white hover:bg-gray-700 rounded-md transition-colors"><ElementsIcon className="w-5 h-5" /></button>
        <button className="p-3 text-gray-400 hover:text-white hover:bg-gray-700 rounded-md transition-colors"><TextIcon className="w-5 h-5" /></button>
        <button className="p-3 text-gray-400 hover:text-white hover:bg-gray-700 rounded-md transition-colors"><ColorsIcon className="w-5 h-5" /></button>
        <button className="p-3 text-gray-400 hover:text-white hover:bg-gray-700 rounded-md transition-colors"><LayersIcon className="w-5 h-5" /></button>
      </div>
    </section>
  );
};
