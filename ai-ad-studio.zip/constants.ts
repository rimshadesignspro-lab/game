
import { Asset } from './types';

// NOTE: For best results, product images should have transparent backgrounds (PNG).
// These placeholders are for demonstration purposes.
export const INITIAL_ASSETS: Asset[] = [
  { id: 'asset-1', name: 'iPhone', url: 'https://res.cloudinary.com/deepwave-org/image/upload/v1717812588/u5qg7rqghvshk2iszgjh.png', type: 'image', mimeType: 'image/png' },
  { id: 'asset-2', name: 'Mug', url: 'https://res.cloudinary.com/deepwave-org/image/upload/v1717812604/tnkhyyluhjiirknzw5b3.png', type: 'image', mimeType: 'image/png' },
  { id: 'asset-3', name: 'Running Shoe', url: 'https://res.cloudinary.com/deepwave-org/image/upload/v1717812615/qqx0tsoqeqk4zcyh3a8m.png', type: 'image', mimeType: 'image/png' },
  { id: 'asset-4', name: 'White Shoe', url: 'https://res.cloudinary.com/deepwave-org/image/upload/v1717812626/v0y7x2v1jgmm82mh9wpa.png', type: 'image', mimeType: 'image/png' },
];

export const BACKGROUND_SUGGESTIONS: string[] = [
  'https://images.pexels.com/photos/1037992/pexels-photo-1037992.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
  'https://images.pexels.com/photos/3290068/pexels-photo-3290068.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
  'https://images.pexels.com/photos/325185/pexels-photo-325185.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
  'https://images.pexels.com/photos/933054/pexels-photo-933054.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
  'https://images.pexels.com/photos/2387873/pexels-photo-2387873.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
  'https://images.pexels.com/photos/1632790/pexels-photo-1632790.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
];

export const INITIAL_BACKGROUND = 'https://images.pexels.com/photos/1229861/pexels-photo-1229861.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2';
